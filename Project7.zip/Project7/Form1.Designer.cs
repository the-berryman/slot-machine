﻿namespace Project7
{
    partial class slotMachineform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(slotMachineform));
            this.slot1Roll1 = new System.Windows.Forms.PictureBox();
            this.slot2Roll1 = new System.Windows.Forms.PictureBox();
            this.slot3Roll1 = new System.Windows.Forms.PictureBox();
            this.moneyInput = new System.Windows.Forms.TextBox();
            this.goButton = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.statusLabel = new System.Windows.Forms.Label();
            this.slot1Roll2 = new System.Windows.Forms.PictureBox();
            this.slot2Roll2 = new System.Windows.Forms.PictureBox();
            this.slot3Roll2 = new System.Windows.Forms.PictureBox();
            this.slot1Roll3 = new System.Windows.Forms.PictureBox();
            this.slot2Roll3 = new System.Windows.Forms.PictureBox();
            this.slot3Roll3 = new System.Windows.Forms.PictureBox();
            this.slot1Roll4 = new System.Windows.Forms.PictureBox();
            this.slot2Roll4 = new System.Windows.Forms.PictureBox();
            this.slot3Roll4 = new System.Windows.Forms.PictureBox();
            this.slot1Roll5 = new System.Windows.Forms.PictureBox();
            this.slot2Roll5 = new System.Windows.Forms.PictureBox();
            this.slot3Roll5 = new System.Windows.Forms.PictureBox();
            this.slot1Roll6 = new System.Windows.Forms.PictureBox();
            this.slot2Roll6 = new System.Windows.Forms.PictureBox();
            this.slot3Roll6 = new System.Windows.Forms.PictureBox();
            this.slot1Roll7 = new System.Windows.Forms.PictureBox();
            this.slot2Roll7 = new System.Windows.Forms.PictureBox();
            this.slot3Roll7 = new System.Windows.Forms.PictureBox();
            this.slot1Roll8 = new System.Windows.Forms.PictureBox();
            this.slot2Roll8 = new System.Windows.Forms.PictureBox();
            this.slot3Roll8 = new System.Windows.Forms.PictureBox();
            this.slot1Roll9 = new System.Windows.Forms.PictureBox();
            this.slot2Roll9 = new System.Windows.Forms.PictureBox();
            this.slot3Roll9 = new System.Windows.Forms.PictureBox();
            this.slot1Roll10 = new System.Windows.Forms.PictureBox();
            this.slot2Roll10 = new System.Windows.Forms.PictureBox();
            this.slot3Roll10 = new System.Windows.Forms.PictureBox();
            this.winningsBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.slotmachinetimer = new System.Windows.Forms.Timer(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.totalBet = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll10)).BeginInit();
            this.SuspendLayout();
            // 
            // slot1Roll1
            // 
            this.slot1Roll1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot1Roll1.BackgroundImage")));
            this.slot1Roll1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot1Roll1.Location = new System.Drawing.Point(12, 67);
            this.slot1Roll1.Name = "slot1Roll1";
            this.slot1Roll1.Size = new System.Drawing.Size(130, 134);
            this.slot1Roll1.TabIndex = 0;
            this.slot1Roll1.TabStop = false;
            // 
            // slot2Roll1
            // 
            this.slot2Roll1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot2Roll1.BackgroundImage")));
            this.slot2Roll1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot2Roll1.Location = new System.Drawing.Point(148, 67);
            this.slot2Roll1.Name = "slot2Roll1";
            this.slot2Roll1.Size = new System.Drawing.Size(130, 134);
            this.slot2Roll1.TabIndex = 1;
            this.slot2Roll1.TabStop = false;
            // 
            // slot3Roll1
            // 
            this.slot3Roll1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot3Roll1.BackgroundImage")));
            this.slot3Roll1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot3Roll1.Location = new System.Drawing.Point(284, 67);
            this.slot3Roll1.Name = "slot3Roll1";
            this.slot3Roll1.Size = new System.Drawing.Size(130, 134);
            this.slot3Roll1.TabIndex = 2;
            this.slot3Roll1.TabStop = false;
            // 
            // moneyInput
            // 
            this.moneyInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moneyInput.Location = new System.Drawing.Point(282, 217);
            this.moneyInput.Name = "moneyInput";
            this.moneyInput.Size = new System.Drawing.Size(114, 29);
            this.moneyInput.TabIndex = 3;
            // 
            // goButton
            // 
            this.goButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.goButton.Location = new System.Drawing.Point(116, 358);
            this.goButton.Name = "goButton";
            this.goButton.Size = new System.Drawing.Size(189, 80);
            this.goButton.TabIndex = 4;
            this.goButton.Text = "Spin!";
            this.goButton.UseVisualStyleBackColor = true;
            this.goButton.Click += new System.EventHandler(this.goButton_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(21, 363);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 6;
            this.button3.Text = "Exit";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusLabel.Location = new System.Drawing.Point(8, 24);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(332, 20);
            this.statusLabel.TabIndex = 7;
            this.statusLabel.Text = "Enter an amount and spin the slot machine!!!!!";
            // 
            // slot1Roll2
            // 
            this.slot1Roll2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot1Roll2.BackgroundImage")));
            this.slot1Roll2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot1Roll2.Location = new System.Drawing.Point(12, 67);
            this.slot1Roll2.Name = "slot1Roll2";
            this.slot1Roll2.Size = new System.Drawing.Size(130, 134);
            this.slot1Roll2.TabIndex = 8;
            this.slot1Roll2.TabStop = false;
            // 
            // slot2Roll2
            // 
            this.slot2Roll2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot2Roll2.BackgroundImage")));
            this.slot2Roll2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot2Roll2.Location = new System.Drawing.Point(148, 67);
            this.slot2Roll2.Name = "slot2Roll2";
            this.slot2Roll2.Size = new System.Drawing.Size(130, 134);
            this.slot2Roll2.TabIndex = 9;
            this.slot2Roll2.TabStop = false;
            // 
            // slot3Roll2
            // 
            this.slot3Roll2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot3Roll2.BackgroundImage")));
            this.slot3Roll2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot3Roll2.Location = new System.Drawing.Point(284, 67);
            this.slot3Roll2.Name = "slot3Roll2";
            this.slot3Roll2.Size = new System.Drawing.Size(130, 134);
            this.slot3Roll2.TabIndex = 10;
            this.slot3Roll2.TabStop = false;
            // 
            // slot1Roll3
            // 
            this.slot1Roll3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot1Roll3.BackgroundImage")));
            this.slot1Roll3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot1Roll3.Location = new System.Drawing.Point(12, 67);
            this.slot1Roll3.Name = "slot1Roll3";
            this.slot1Roll3.Size = new System.Drawing.Size(130, 134);
            this.slot1Roll3.TabIndex = 11;
            this.slot1Roll3.TabStop = false;
            // 
            // slot2Roll3
            // 
            this.slot2Roll3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot2Roll3.BackgroundImage")));
            this.slot2Roll3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot2Roll3.Location = new System.Drawing.Point(148, 67);
            this.slot2Roll3.Name = "slot2Roll3";
            this.slot2Roll3.Size = new System.Drawing.Size(130, 134);
            this.slot2Roll3.TabIndex = 12;
            this.slot2Roll3.TabStop = false;
            // 
            // slot3Roll3
            // 
            this.slot3Roll3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot3Roll3.BackgroundImage")));
            this.slot3Roll3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot3Roll3.Location = new System.Drawing.Point(284, 67);
            this.slot3Roll3.Name = "slot3Roll3";
            this.slot3Roll3.Size = new System.Drawing.Size(130, 134);
            this.slot3Roll3.TabIndex = 13;
            this.slot3Roll3.TabStop = false;
            // 
            // slot1Roll4
            // 
            this.slot1Roll4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot1Roll4.BackgroundImage")));
            this.slot1Roll4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot1Roll4.Location = new System.Drawing.Point(12, 67);
            this.slot1Roll4.Name = "slot1Roll4";
            this.slot1Roll4.Size = new System.Drawing.Size(130, 134);
            this.slot1Roll4.TabIndex = 14;
            this.slot1Roll4.TabStop = false;
            // 
            // slot2Roll4
            // 
            this.slot2Roll4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot2Roll4.BackgroundImage")));
            this.slot2Roll4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot2Roll4.Location = new System.Drawing.Point(148, 67);
            this.slot2Roll4.Name = "slot2Roll4";
            this.slot2Roll4.Size = new System.Drawing.Size(130, 134);
            this.slot2Roll4.TabIndex = 15;
            this.slot2Roll4.TabStop = false;
            // 
            // slot3Roll4
            // 
            this.slot3Roll4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot3Roll4.BackgroundImage")));
            this.slot3Roll4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot3Roll4.Location = new System.Drawing.Point(284, 67);
            this.slot3Roll4.Name = "slot3Roll4";
            this.slot3Roll4.Size = new System.Drawing.Size(130, 134);
            this.slot3Roll4.TabIndex = 16;
            this.slot3Roll4.TabStop = false;
            // 
            // slot1Roll5
            // 
            this.slot1Roll5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot1Roll5.BackgroundImage")));
            this.slot1Roll5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot1Roll5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.slot1Roll5.Location = new System.Drawing.Point(12, 67);
            this.slot1Roll5.Name = "slot1Roll5";
            this.slot1Roll5.Size = new System.Drawing.Size(130, 134);
            this.slot1Roll5.TabIndex = 17;
            this.slot1Roll5.TabStop = false;
            // 
            // slot2Roll5
            // 
            this.slot2Roll5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot2Roll5.BackgroundImage")));
            this.slot2Roll5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot2Roll5.Location = new System.Drawing.Point(148, 67);
            this.slot2Roll5.Name = "slot2Roll5";
            this.slot2Roll5.Size = new System.Drawing.Size(130, 134);
            this.slot2Roll5.TabIndex = 18;
            this.slot2Roll5.TabStop = false;
            // 
            // slot3Roll5
            // 
            this.slot3Roll5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot3Roll5.BackgroundImage")));
            this.slot3Roll5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot3Roll5.Location = new System.Drawing.Point(284, 67);
            this.slot3Roll5.Name = "slot3Roll5";
            this.slot3Roll5.Size = new System.Drawing.Size(130, 134);
            this.slot3Roll5.TabIndex = 19;
            this.slot3Roll5.TabStop = false;
            // 
            // slot1Roll6
            // 
            this.slot1Roll6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot1Roll6.BackgroundImage")));
            this.slot1Roll6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot1Roll6.Location = new System.Drawing.Point(12, 67);
            this.slot1Roll6.Name = "slot1Roll6";
            this.slot1Roll6.Size = new System.Drawing.Size(130, 134);
            this.slot1Roll6.TabIndex = 20;
            this.slot1Roll6.TabStop = false;
            // 
            // slot2Roll6
            // 
            this.slot2Roll6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot2Roll6.BackgroundImage")));
            this.slot2Roll6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot2Roll6.Location = new System.Drawing.Point(148, 67);
            this.slot2Roll6.Name = "slot2Roll6";
            this.slot2Roll6.Size = new System.Drawing.Size(130, 134);
            this.slot2Roll6.TabIndex = 21;
            this.slot2Roll6.TabStop = false;
            // 
            // slot3Roll6
            // 
            this.slot3Roll6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot3Roll6.BackgroundImage")));
            this.slot3Roll6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot3Roll6.Location = new System.Drawing.Point(284, 67);
            this.slot3Roll6.Name = "slot3Roll6";
            this.slot3Roll6.Size = new System.Drawing.Size(130, 134);
            this.slot3Roll6.TabIndex = 22;
            this.slot3Roll6.TabStop = false;
            // 
            // slot1Roll7
            // 
            this.slot1Roll7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot1Roll7.BackgroundImage")));
            this.slot1Roll7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot1Roll7.Location = new System.Drawing.Point(12, 67);
            this.slot1Roll7.Name = "slot1Roll7";
            this.slot1Roll7.Size = new System.Drawing.Size(130, 134);
            this.slot1Roll7.TabIndex = 23;
            this.slot1Roll7.TabStop = false;
            // 
            // slot2Roll7
            // 
            this.slot2Roll7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot2Roll7.BackgroundImage")));
            this.slot2Roll7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot2Roll7.Location = new System.Drawing.Point(148, 67);
            this.slot2Roll7.Name = "slot2Roll7";
            this.slot2Roll7.Size = new System.Drawing.Size(130, 134);
            this.slot2Roll7.TabIndex = 24;
            this.slot2Roll7.TabStop = false;
            // 
            // slot3Roll7
            // 
            this.slot3Roll7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot3Roll7.BackgroundImage")));
            this.slot3Roll7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot3Roll7.Location = new System.Drawing.Point(284, 67);
            this.slot3Roll7.Name = "slot3Roll7";
            this.slot3Roll7.Size = new System.Drawing.Size(130, 134);
            this.slot3Roll7.TabIndex = 25;
            this.slot3Roll7.TabStop = false;
            // 
            // slot1Roll8
            // 
            this.slot1Roll8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot1Roll8.BackgroundImage")));
            this.slot1Roll8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot1Roll8.Location = new System.Drawing.Point(12, 67);
            this.slot1Roll8.Name = "slot1Roll8";
            this.slot1Roll8.Size = new System.Drawing.Size(130, 134);
            this.slot1Roll8.TabIndex = 26;
            this.slot1Roll8.TabStop = false;
            // 
            // slot2Roll8
            // 
            this.slot2Roll8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot2Roll8.BackgroundImage")));
            this.slot2Roll8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot2Roll8.Location = new System.Drawing.Point(148, 67);
            this.slot2Roll8.Name = "slot2Roll8";
            this.slot2Roll8.Size = new System.Drawing.Size(130, 134);
            this.slot2Roll8.TabIndex = 27;
            this.slot2Roll8.TabStop = false;
            // 
            // slot3Roll8
            // 
            this.slot3Roll8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot3Roll8.BackgroundImage")));
            this.slot3Roll8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot3Roll8.Location = new System.Drawing.Point(284, 67);
            this.slot3Roll8.Name = "slot3Roll8";
            this.slot3Roll8.Size = new System.Drawing.Size(130, 134);
            this.slot3Roll8.TabIndex = 28;
            this.slot3Roll8.TabStop = false;
            // 
            // slot1Roll9
            // 
            this.slot1Roll9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot1Roll9.BackgroundImage")));
            this.slot1Roll9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot1Roll9.Location = new System.Drawing.Point(12, 67);
            this.slot1Roll9.Name = "slot1Roll9";
            this.slot1Roll9.Size = new System.Drawing.Size(130, 134);
            this.slot1Roll9.TabIndex = 29;
            this.slot1Roll9.TabStop = false;
            // 
            // slot2Roll9
            // 
            this.slot2Roll9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot2Roll9.BackgroundImage")));
            this.slot2Roll9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot2Roll9.Location = new System.Drawing.Point(148, 67);
            this.slot2Roll9.Name = "slot2Roll9";
            this.slot2Roll9.Size = new System.Drawing.Size(130, 134);
            this.slot2Roll9.TabIndex = 30;
            this.slot2Roll9.TabStop = false;
            // 
            // slot3Roll9
            // 
            this.slot3Roll9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot3Roll9.BackgroundImage")));
            this.slot3Roll9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot3Roll9.Location = new System.Drawing.Point(284, 67);
            this.slot3Roll9.Name = "slot3Roll9";
            this.slot3Roll9.Size = new System.Drawing.Size(130, 134);
            this.slot3Roll9.TabIndex = 31;
            this.slot3Roll9.TabStop = false;
            // 
            // slot1Roll10
            // 
            this.slot1Roll10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot1Roll10.BackgroundImage")));
            this.slot1Roll10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot1Roll10.Location = new System.Drawing.Point(12, 67);
            this.slot1Roll10.Name = "slot1Roll10";
            this.slot1Roll10.Size = new System.Drawing.Size(130, 134);
            this.slot1Roll10.TabIndex = 32;
            this.slot1Roll10.TabStop = false;
            // 
            // slot2Roll10
            // 
            this.slot2Roll10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot2Roll10.BackgroundImage")));
            this.slot2Roll10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot2Roll10.Location = new System.Drawing.Point(148, 67);
            this.slot2Roll10.Name = "slot2Roll10";
            this.slot2Roll10.Size = new System.Drawing.Size(130, 134);
            this.slot2Roll10.TabIndex = 33;
            this.slot2Roll10.TabStop = false;
            // 
            // slot3Roll10
            // 
            this.slot3Roll10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slot3Roll10.BackgroundImage")));
            this.slot3Roll10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slot3Roll10.Location = new System.Drawing.Point(284, 67);
            this.slot3Roll10.Name = "slot3Roll10";
            this.slot3Roll10.Size = new System.Drawing.Size(130, 134);
            this.slot3Roll10.TabIndex = 34;
            this.slot3Roll10.TabStop = false;
            // 
            // winningsBox
            // 
            this.winningsBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.winningsBox.Location = new System.Drawing.Point(282, 287);
            this.winningsBox.Name = "winningsBox";
            this.winningsBox.Size = new System.Drawing.Size(114, 29);
            this.winningsBox.TabIndex = 35;
            this.winningsBox.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(47, 220);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(229, 24);
            this.label2.TabIndex = 37;
            this.label2.Text = "Money to enter this round:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(162, 290);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 24);
            this.label3.TabIndex = 38;
            this.label3.Text = "Money won:";
            // 
            // slotmachinetimer
            // 
            this.slotmachinetimer.Interval = 25;
            this.slotmachinetimer.Tick += new System.EventHandler(this.slotmachinetimer_Tick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(87, 255);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(189, 24);
            this.label4.TabIndex = 42;
            this.label4.Text = "Total Money entered:";
            // 
            // totalBet
            // 
            this.totalBet.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalBet.Location = new System.Drawing.Point(282, 252);
            this.totalBet.Name = "totalBet";
            this.totalBet.Size = new System.Drawing.Size(114, 29);
            this.totalBet.TabIndex = 41;
            this.totalBet.Text = "0";
            // 
            // slotMachineform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.totalBet);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.winningsBox);
            this.Controls.Add(this.slot3Roll10);
            this.Controls.Add(this.slot2Roll10);
            this.Controls.Add(this.slot1Roll10);
            this.Controls.Add(this.slot3Roll9);
            this.Controls.Add(this.slot2Roll9);
            this.Controls.Add(this.slot1Roll9);
            this.Controls.Add(this.slot3Roll8);
            this.Controls.Add(this.slot2Roll8);
            this.Controls.Add(this.slot1Roll8);
            this.Controls.Add(this.slot3Roll7);
            this.Controls.Add(this.slot2Roll7);
            this.Controls.Add(this.slot1Roll7);
            this.Controls.Add(this.slot3Roll6);
            this.Controls.Add(this.slot2Roll6);
            this.Controls.Add(this.slot1Roll6);
            this.Controls.Add(this.slot3Roll5);
            this.Controls.Add(this.slot2Roll5);
            this.Controls.Add(this.slot1Roll5);
            this.Controls.Add(this.slot3Roll4);
            this.Controls.Add(this.slot2Roll4);
            this.Controls.Add(this.slot1Roll4);
            this.Controls.Add(this.slot3Roll3);
            this.Controls.Add(this.slot2Roll3);
            this.Controls.Add(this.slot1Roll3);
            this.Controls.Add(this.slot3Roll2);
            this.Controls.Add(this.slot2Roll2);
            this.Controls.Add(this.slot1Roll2);
            this.Controls.Add(this.statusLabel);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.goButton);
            this.Controls.Add(this.moneyInput);
            this.Controls.Add(this.slot3Roll1);
            this.Controls.Add(this.slot2Roll1);
            this.Controls.Add(this.slot1Roll1);
            this.Name = "slotMachineform";
            this.Text = "Test your luck!!";
            this.Load += new System.EventHandler(this.slotMachineform_Load);
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1Roll10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot2Roll10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot3Roll10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox slot1Roll1;
        private System.Windows.Forms.PictureBox slot2Roll1;
        private System.Windows.Forms.PictureBox slot3Roll1;
        private System.Windows.Forms.TextBox moneyInput;
        private System.Windows.Forms.Button goButton;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.PictureBox slot1Roll2;
        private System.Windows.Forms.PictureBox slot2Roll2;
        private System.Windows.Forms.PictureBox slot3Roll2;
        private System.Windows.Forms.PictureBox slot1Roll3;
        private System.Windows.Forms.PictureBox slot2Roll3;
        private System.Windows.Forms.PictureBox slot3Roll3;
        private System.Windows.Forms.PictureBox slot1Roll4;
        private System.Windows.Forms.PictureBox slot2Roll4;
        private System.Windows.Forms.PictureBox slot3Roll4;
        private System.Windows.Forms.PictureBox slot1Roll5;
        private System.Windows.Forms.PictureBox slot2Roll5;
        private System.Windows.Forms.PictureBox slot3Roll5;
        private System.Windows.Forms.PictureBox slot1Roll6;
        private System.Windows.Forms.PictureBox slot2Roll6;
        private System.Windows.Forms.PictureBox slot3Roll6;
        private System.Windows.Forms.PictureBox slot1Roll7;
        private System.Windows.Forms.PictureBox slot2Roll7;
        private System.Windows.Forms.PictureBox slot3Roll7;
        private System.Windows.Forms.PictureBox slot1Roll8;
        private System.Windows.Forms.PictureBox slot2Roll8;
        private System.Windows.Forms.PictureBox slot3Roll8;
        private System.Windows.Forms.PictureBox slot1Roll9;
        private System.Windows.Forms.PictureBox slot2Roll9;
        private System.Windows.Forms.PictureBox slot3Roll9;
        private System.Windows.Forms.PictureBox slot1Roll10;
        private System.Windows.Forms.PictureBox slot2Roll10;
        private System.Windows.Forms.PictureBox slot3Roll10;
        private System.Windows.Forms.TextBox winningsBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer slotmachinetimer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox totalBet;
    }
}

